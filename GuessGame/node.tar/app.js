var express = require('express');
var ejs=require('ejs');

var app = express();

app.use(express.json()); // for parsing application/json
app.use(express.urlencoded({ extended: true }));// for parsing application/x-www-form-urlencoded
app.use('/static/',express.static("./static/"));
app.engine('html',ejs.__express);
app.set('view engine','html');


var config = {
    "forbidAdmin" : true,
    //"enableReg" : true
};
var loginHistory = [];
var adminName = "admin888";
var flag = "g3tF1AaGEAzY";


const isObject = obj => obj && obj.constructor && obj.constructor === Object;

function merge(a, b) {
    for (let attr in b) {
        if (isObject(a[attr]) && isObject(b[attr])) {
            merge(a[attr], b[attr]);
        } else {
            a[attr] = b[attr];
        }
    }
    return a;
}


function log(userInfo){
    let logItem = {"time":new Date().toString()};
    merge(logItem,userInfo);
    loginHistory.push(logItem);
}


app.get('/log', function (req,res) {
    if(loginHistory.length==0){
        res.end("no log");
    }else {
        res.json(loginHistory);
    }
});


app.get('/', function (req, res) {
    res.render("index");
});


//So terrible code~
app.post('/',function (req, res) {
    if(typeof req.body.user.username != "string"){
        res.end("error");
    }else {
        //console.log(req.body.user.username);
        if(config.forbidAdmin && req.body.user.username.includes("admin")){
            res.end("any admin user has been baned");
        }else {
            if(req.body.user.username.toUpperCase() === adminName.toUpperCase())
                //only log admin's activity
                log(req.body.user);
            res.end("ok");
        }
    }
});

app.get('/verifyFlag', function (req, res) {
    res.render("verifyFlag");
});


app.post('/verifyFlag',function (req,res) {
    //let result = "Your match flag is here: ";
    let result = "Emm~ I won't tell you what happened! ";

    if(typeof req.body.q != "string"){
        res.end("please input your guessing flag");
    }else{
        let regExp = req.body.q;
        if(config.enableReg && noDos(regExp) && flag.match(regExp)){
            //res.end(flag);
            //Stop your wishful thinking and go away!
        }
        if(req.query.q === flag)
            result+=flag;
        res.end(result);
    }
});

function noDos(regExp) {
    //match regExp like this will be too hard
    return !(regExp.length>30||regExp.match(/[)]/g).length>5);
}

var server = app.listen(8081, function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log("http://%s:%s", host, port)
});